let perguntas = [
  {
    pergunta: "O que o campo fornece para a cidade?",
    opcoes: ["Internet", "Comida", "Shopping"],
    correta: 1
  },
  {
    pergunta: "Qual é uma prática sustentável no campo?",
    opcoes: ["Queimar florestas", "Usar agrotóxicos sem controle", "Rotação de culturas"],
    correta: 2
  },
  {
    pergunta: "O que a cidade pode oferecer ao campo?",
    opcoes: ["Educação", "Fome", "Poluição"],
    correta: 0
  },
  {
    pergunta: "Como o lixo urbano afeta o campo?",
    opcoes: ["Melhora a terra", "Polui rios", "Faz crescer mais planta"],
    correta: 1
  }
];

let perguntaAtual = 0;
let pontos = 0;
let vidas = 3;

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
  textSize(18);
}

function draw() {
  background(200, 250, 200);
  fill(0);
  text("Festejando a Conexão Campo-Cidade - QUIZ", width / 2, 30);
  text("Pontos: " + pontos + " | Vidas: " + vidas, width / 2, 60);

  if (vidas <= 0) {
    textSize(32);
    fill(255, 0, 0);
    text("Fim de jogo!", width / 2, height / 2);
    noLoop();
    return;
  }

  if (perguntaAtual >= perguntas.length) {
    textSize(28);
    fill(0, 150, 0);
    text("Parabéns! Você completou o quiz!", width / 2, height / 2);
    noLoop();
    return;
  }

  let p = perguntas[perguntaAtual];

  textSize(20);
  fill(0);
  text(p.pergunta, width / 2, 120);

  for (let i = 0; i < p.opcoes.length; i++) {
    fill(255);
    rect(100, 160 + i * 60, 400, 40);
    fill(0);
    text(p.opcoes[i], 300, 180 + i * 60);
  }
}

function mousePressed() {
  if (vidas <= 0 || perguntaAtual >= perguntas.length) return;

  let p = perguntas[perguntaAtual];

  for (let i = 0; i < p.opcoes.length; i++) {
    if (
      mouseX > 100 &&
      mouseX < 500 &&
      mouseY > 160 + i * 60 &&
      mouseY < 200 + i * 60
    ) {
      if (i === p.correta) {
        pontos++;
      } else {
        vidas--;
      }
      perguntaAtual++;
    }
  }
}
